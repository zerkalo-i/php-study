<?php

$a = '78';
$b = 78;

if ($a == $b)
{echo "равны";}
else
{echo "не равны";}


