<?php

//Константы определяются функцией define()

define('DAYS_COUNT', 7);
define('MONTH_COUNT', 12);

echo DAYS_COUNT;
echo '<br>';
echo MONTH_COUNT;
echo '<br>';

//Константы определяются ключевым словом const

const DAYS_COUNT_2 = 7;
const MONTH_COUNT_2 = 12;

echo DAYS_COUNT_2;
echo '<br>';
echo MONTH_COUNT_2;
