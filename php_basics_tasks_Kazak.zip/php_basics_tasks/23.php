<?php
$a = "Первая строка, выведена классическим способом";
$b = "Вторая строка";
$c = "Третья строка";

echo $a ;
echo '<pre>';
var_dump($b);
echo '</pre>';

echo '<pre>';
print_r($c);
echo '</pre>';




